# https://www.hackerrank.com/challenges/whats-your-name/problem
# 9 What's Your Name?

def print_full_name(first, last):
    print(f"Hello {first} {last}! You just delved into python.")

if __name__ == '__main__':
    first_name = input()
    last_name = input()
    print_full_name(first_name, last_name)
