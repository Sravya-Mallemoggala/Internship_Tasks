# https://www.hackerrank.com/challenges/python-loops/problem
# 4 Loops

if __name__ == '__main__':
    n = int(input())
    for i in range(n):
        print(i**2)
